# LiquidCrystal_I2C
Personalización de la librería LiquidCrystal_I2C de Marco Schwartz con ejemplos modificados para simplificar el aprendizaje.
